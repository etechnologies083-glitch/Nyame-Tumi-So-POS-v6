NYAME TUMI SO ENTERPRISE POS — VERSION 3

Built from the supplied shop details:
- Nyame Tumi So Enterprise
- Wholesale Foodstuffs and Provisions
- Kade opposite entrance of Kade station
- 0245690035 / 0556141002
- Advertised products: Parboiled Rice, Golden Morn, Milo and Milk Refill, Food Spices, Checkers Custard etc.

Version 3 modules:
Dashboard, POS/barcode scanning, Products, Purchases/stock receiving, Stock overview, Expenses, Sales reports, Shop Settings, backup/restore, low-stock alerts, branded receipts.

Usage:
1. Extract the ZIP.
2. Open index.html in Chrome, Edge or Firefox.
3. Add real products with their actual barcode, price and stock.
4. For a USB barcode scanner, focus the POS scan box and scan; most scanners act like a keyboard and send Enter.
5. Use Settings > Download Backup regularly.

This is an offline browser application. Data is stored locally in the browser on that computer. It does not yet synchronize between multiple computers or provide a server/database.
